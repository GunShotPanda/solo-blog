title: 旧文：win10 + kalilinxu双系统踩坑实录
date: '2019-08-09 20:10:43'
updated: '2019-08-09 20:11:38'
tags: [老物, linux, 技术]
permalink: /articles/2019/08/09/1565352643618.html
---

没啥用，且以后不会更新哈哈。
----------------------------------------------------------
## 牢骚 ##
额，不愿意看我发牢骚的同学可以直接看下面干货了
前阵子Kali 2.0发布 心血来潮，本来我的电脑是SP3 256G I7 ,Win10+Ubuntu 14.04 双系统。由Ubuntu安装时自带的grub 引导。当时我装双系统也是为了上操作系统课方便一些，没成想Surface真是有毒啊，上篇博客也提到了Ubuntu 14.04对SP3的硬件支持并不是很好，照着github上一个大神的项目重新编译了下内核才整好。而这次，无知且热爱作死的我 ，又一次作死了。
##Win10 +Kali linux 2.0 双系统安装指南##
我用系统自带的“创建与格式化硬盘空间”将原硬盘分出了大约60G的空间用作第二系统Linux的空间。然后下载了[Ubuntu官方][7] 的 Ubuntu 14.04 的ISO镜像文件，制作USB系统盘的话，我推荐 [Win32DiskImager][8] ,使用它制作镜像盘的话要注意，如果你想清除镜像并重新使用这个U盘的话光格式化是不够的，还需要在命令提示符启动 DISKPART 
```
lis disk//列出当前设备可用的磁盘
select disk (which you want) //选择你的USB磁盘编号
clean //彻底清除磁盘
create partition primary //创建主分区
active//激活主分区
exit
```
然后再格式化你的硬盘，你会发现他的空间又回来了。
那么我们使用这个工具将镜像烧录到U盘上，镜像盘就制作好了。
SP3的使用者要注意，surface系列使用的固件系统是EFI，与传统的BIOS是不同的，我们先要进入 设置-》更新和安全-》修复-》高级启动来进入UEFI固件系统，进入后我们需要修改固件的系统启动顺序为USB->SSD ，并且将Secure Boot 设置为 disable，这样我们才能用镜像盘引导启动。
安装Ubuntu的流程我就不说了，分区的时候提一下，我分区习惯很差，直接找8G空间（和内存大小差不多）作为Linux 的swap（交换空间），然后剩下的52G直接设置为ext4日志文件系统，挂载到root，也就是/根目录。然后分区就可以了，其实这样造成的问题会很多，大家可以按照自己的习惯科学分区，这里我就不赘述了。
安装完成后Ubuntu 会安装grub 引导 ，以后我们的电脑就以grub引导开机并选择要使用的系统，是不是很棒？

--------------------------------------------------------------------
##在原有双系统基础上覆盖第二系统安装kali linux##
接下来就是我写这篇博客的原因了
制作镜像盘的步骤基本与上一章一样,附镜像链接[kali linux 2.0][9] 安装Kali的步骤也基本一样，只要把原来Ubuntu的分区内容擦除，照着原来的设置挂载上去就好，kali linux 2.0自带grub2 引导 会自动安装并替换你原来的引导，注意 ：篓子就出在这里 是替换 而不是覆盖！
在我以为能尽情享受kali 带来的乐趣时 ，我手贱在终端输入了
```
sudo grub-mkconfig -o /boot/grub/grub.cfg
```
然后出去办事了，这条命令是linux通用更新grub的命令，我在回来以后忘记了这条命令依然在执行，关闭了系统。
于是，翌日，我的电脑开机变成了这个鸟样
这是grub shell 
![这里写图片描述](https://imgconvert.csdnimg.cn/aHR0cDovL21lZGlhLnRlY2h0YXJnZXQuY29tL2RpZ2l0YWxndWlkZS9pbWFnZXMvTWlzYy9maWd1dXIxLmdpZg)
这个是正常的grub(不是我的)
![这里写图片描述](https://imgconvert.csdnimg.cn/aHR0cDovL2ltZy5ibG9nLmNzZG4ubmV0LzIwMTQwOTI0MDkxOTIyNzA5)

**我靠劳资的系统呢？！**
不幸中的万幸  输入exit回车还是回到了我熟悉的windows，没想到这才是折腾的开始。
我以为只是grub2在安装时出了问题，和mbr冲突了，于是插上镜像盘又装了一遍。
grub2 在安装到一半是提示我：
```
执行 grub-install dummy 失败
```
我靠，这就有点尴尬了。
这时，我开始逃避问题了，不愿意去一条命令一条命令检查错误，心里想着，grub 2不行的话我换回grub 1 吧 ，于是又拿Ubuntu的镜像盘装了一遍，不出所料，grub同样安装失败。
## grub 2 引导详解##
废话不多说，掏干货了。

- **grub2和grub有很多不同的地方**
a）图形接口
b）使用了模块机制，通过动态加载需要的模块来扩展功能
c）支持脚本语言，例如条件判断，循环、变量和函数
d）支持rescue模式，可用于系统无法引导的情况
e）国际化语言。包括支持非ASCII的字符集和类似gettext的消息分类，字体，图形控制台等等
f）有一个灵活的命令行接口。如果没有配置文件存在，GRUB会自动进入命令模式
g）针对文件系统、文件、设备、驱动、终端、命令、分区表、os loder的模块化、层次化、基于对象的框架
h）支持多种文件系统格式
i）可访问已经安装的设备上的数据
j）支持自动解压

- **设备的命名**
grub2同样以fd表示软盘，hd表示硬盘（包含IDE和SCSI硬盘）。设备是从0开始编号，分区则是从1开始，主分区从1-4，逻辑分区从5开始。下面给出几个例子 ：
(fd0)：表示整个软盘
(hd0,1)：表示第一个硬盘的第1个分区
(hd0,5)/boot/vmlinuz：表示第一个硬盘的第一个逻辑分区下的boot目录下的vmlinuz文件

- **grub2启动**

  grub2默认安装在第一硬盘（hd0）的mbr，其实就是把引导文件boot.img写入硬盘的mbr，当然，用户也可以选择不写入硬盘mbr而是写入linux分区的引导扇区。启动时根据mbr所提供信息找到启动分区后，加载分区内的grub核心文件core.img和配置文件grub.cfg，进入选择菜单画面。
可以用命令行启动系统，比如启动第二硬盘第一逻辑分区上的ubuntu系统：
```
grub>set root=(hd1,5)
grub>linux /boot/vmlinuz-xxx-xxx root=/dev/sdb5
grub>initrd /boot/initrd.img-xxx-xxx
grub>boot
```
其中内核vmlinuz和initrd.img的版本号可按tab自动补全

- **grub.cfg详解**
博主的系统正是因为重复安装不同版本的grub且未将之前的grub版本清楚感觉而导致grub找不到grub.cfg，使系统开机显示grub shell界面，所以，千万不要手贱去动grub.cfg!
grub.cfg默认为只读，需要个性化配置文件的，建议不要直接修改grub.cfg，请参考链接的pdf文档和[google文档][10]。

```
set default=0
#默认为0
 insmod jpeg
#添加jpg支持，如要使用png或tga文件做背景，加上 insmod png或insmod tga
 insmod ext2
#除了用作启动的分区外，其他分区格式可在menu底下再添加
set root=(hd0,7)
#设定root分区
search --no-floppy --fs-uuid --set f255285a-5ad4-4eb8-93f5-4f767190d3b3
#设定uuid=****的分区为root，和上句重复，可删除
# 以下为终端配置
if loadfont /usr/share/grub/unicode.pf2 ; then
#设置终端字体，unicode.pf2支持中文显示
set gfxmode=640x480
#设置分辨率，默认为 640x480，可用800x600，1024x768，建议跟你想设定的图片大小一致
insmod gfxterm
#插入模块 gfxterm，支持中文显 示，它还支持 24 位图像
insmod vbe
#插入 vbe 模块，GRUB 2 引入很多模块的东西，要使用它，需要在这里加入
if terminal_output gfxterm ; then true ; else
 # For backward compatibility with versions of terminal.mod that don't
 # understand terminal_output
 terminal gfxterm
#设置 GRUB 2 终端为 gfxterm
 fi
 fi
 set timeout=10

#该延时比较关键，出现grub rescue时时间设置久点就可以进入系统，可能是匹配到UUID的原因
 background_image (hd0,7)/boot/images/1.jpg
#设置背景图片
### END /etc/grub.d/00_header ###

 ### BEGIN /etc/grub.d/05_debian_theme ###
 set menu_color_normal=white/black
 set menu_color_highlight=cyan/black
#这两行为 Debian 下的菜单颜色设置，如果默认的话，你会发现背景完全被蓝色挡住了，你需要修改 blue 为 black，这样背景就会出现 
### END /etc/grub.d/05_debian_theme ###

# 10_linux 为自动添加的当前root分区linux引导项
### BEGIN /etc/grub.d/10_linux ###
#菜单项，要包括 menuentry 双引号" " 和大括号 { }才完整，否则不显示菜单
menuentry "Ubuntu, Linux 2.6.31-9-386" {
 insmod ext2
 set root=(hd0,7)
 search --no-floppy --fs-uuid --set f255285a-5ad4-4eb8-93f5-4f767190d3b3
#这句与set root=(hd0,7)重复，可删除
linux /boot/vmlinuz-2.6.31-9-386 root=UUID=f255285a-5ad4-4eb8-93f5-4f767190d3b3 ro quite splash
#不喜欢看到一长串的， roo=UUID=***可用root=/dev/sda7代替
initrd /boot/initrd.img-2.6.31-9-386
 }
 ### END /etc/grub.d/10_linux ###

 ### BEGIN /etc/grub.d/20_memtest86+ ###
 menuentry "Memory test (memtest86+)" {
 linux16 /boot/memtest86+.bin
 }
 ### END /etc/grub.d/20_memtest86+ ###
```
##grub 2引导修复的几种方法（未完）##
- **重新安装，修复grub2**
attention,please! 当你的grub2 确实损坏了 开机启动的界面不是grub shell 而是 grub secure ，此法有效。
先使用ls命令，找到Ubuntu的安装在哪个分区：在 grub rescue>下输入以下命令：ls。会罗列所有的磁盘分区信息，比方说：引用:
```
(hd0,1),(hd0,5),(hd0,3),(hd0,2)
```
然后一次带哦用如下命令试探：X表示各个分区号码。如果/boot没有单独分区，用一下命令：代码：
```
ls(hd0,X)/boot/grub
```
如果/boot单独分区，则用下列命令：代码：
```
ls (hd0,x)/grub
```
正常情况下，会列出来几百个文件，很多文件的扩展名是.mod和.lst和.img，还有一个文件是grub.cfg。假设找到（hd0,5）时，显示了文件夹中的文件，则表示Linux安装在这个分区。

如果找到了正确的grub目录，则设法临时性将grub的两部分关联起来，方法如下：
        以下是/boot没有单独分区的命令：引用:
```
grub rescue>set root=(hd0,5)  
grub rescue>set prefix=(hd0,5)/boot/grub  
grub rescue>insmod /boot/grub/normal.mod  
```
然后调用如下的命令，就可以显示出丢失的grub菜单了。
```
grub rescue>normal
```
-------------------

## 后记
2015年刚捣鼓linux双系统，心血来潮想搞个渗透，装了kali以后就再没有下文了，公开处刑第三篇。

参考原文: 
http://blog.csdn.net/zhandoushi1982/article/details/39404439
参考原文: 
https://www.openfoundry.org/tw/foss-programs/9267-linux-grub2-fixing
[1]: http://math.stackexchange.com/
[2]: https://github.com/jmcmanus/pagedown-extra "Pagedown Extra"
[3]: http://meta.math.stackexchange.com/questions/5020/mathjax-basic-tutorial-and-quick-reference
[4]: http://bramp.github.io/js-sequence-diagrams/
[5]: http://adrai.github.io/flowchart.js/
[6]: https://github.com/benweet/stackedit
[7]: http://www.ubuntu.com/download/desktop
[8]: https://sourceforge.net/projects/win32diskimager/
[9]: https://www.kali.org/downloads/
[10]: https://www.gnu.org/software/grub/manual/grub.html
