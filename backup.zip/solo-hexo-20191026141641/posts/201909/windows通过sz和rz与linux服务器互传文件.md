title: windows通过sz和rz与linux服务器互传文件
date: '2019-09-02 15:27:42'
updated: '2019-09-02 15:27:42'
tags: [技术, linux]
permalink: /articles/2019/09/02/1567409262221.html
---
![](https://img.hacpai.com/bing/20190405.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# windows通过sz和rz与linux服务器互传文件

###### 最近为公司的新虚拟机部署基础环境，访问虚拟机需要经过跳板机，使用SCP一个一个传文件太麻烦，看到用MAC的同事rz,sz很是洒脱，我寻思给我也整一个！

发现基于lrzsz的zssh工具，不能用于CMD , BASH , CMDER等终端工具，命令不能正常使用。

根据博文的指示用xshell进行配置，这回rz命令可以弹窗了，但是刚开始下载，传输框消失并转入终端内，且终端内乱码。

坊间传闻 sz,rz适合传输小文件，那么是多小的文件多大的文件呢？

在xshell 通过ssh 登录跳板机，再登录服务器，进行rz接收文件传输，大于10m的文件会失败，研究发现rz命令有如下参数：

> -a, -ascii.
> 
> -b,-binary 用binary方式上传下载，不解释字符为ascii.
> 
> -e, –escape 强制escape 所有控制字符，比如 Ctrl+x，DEL 等.
> 
> -ary –o-sync -a 表示使用ascii码格式传输文件，如果是Dos格式的文件，会转换为unix格式.  -r 使用 Crash recovery mode. 即文件传输中断会重传.  -y 表示文件已存在的时候会覆盖.  –o-sync 采用同步写模式，以处理从缓存写到磁盘时中断丢失的情况.

于是使用`rz -be`来传输文件，保证不会中断。

但是在传输超过30m的文件时，又出现了中断且乱码的情况。

于是查看xshell的连接属性中关于ZMODEM的设置
![xshell.PNG](https://img.hacpai.com/file/2019/09/xshell-7b492622.PNG)


发现可能在终端内执行rz命令 ，又会执行一遍xshell设置的参数，所以清空了参数，测试还是会断连。

** 最终，使用xshell自带右键工具ZMODEM发送文件，得以正常完整的传输完所有的文件 **
