title: 旧文：codeblocks
date: '2019-08-09 19:58:24'
updated: '2019-08-09 20:10:52'
tags: [老物, ACM, 技术]
permalink: /articles/2019/08/09/1565351904043.html
---
![](https://img.hacpai.com/bing/20190428.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

 首先，接触codeblocks是因为ACM，然后，在安装codeblocks的时候不要去百度软件中心或者360软件中心——你问我为啥？你可以装装看。
那么，我们该选择哪个版本呢？
（看下图）我们应该选择官网http://www.codeblocks.org/
![这里我们选择第三个有GCC编译器的版本](https://imgconvert.csdnimg.cn/aHR0cDovL2ltZy5ibG9nLmNzZG4ubmV0LzIwMTUwNDE4MTYxMjU5Mjk4)
然后，我们在安装的时候，尽量选择默认路径，如（C:\Program Files\CodeBlocks)
然后我们在初次运行的时候 可能不会创建工程，那么首先，我们创建一个控制台工程：![这里写图片描述](https://imgconvert.csdnimg.cn/aHR0cDovL2ltZy5ibG9nLmNzZG4ubmV0LzIwMTUwNDE4MTYxNzUzMDE2)
codeblocks很贴心，在你设置完工程路径和工程名后，会自动创建一个main.cpp供你测试。![这里写图片描述](https://imgconvert.csdnimg.cn/aHR0cDovL2ltZy5ibG9nLmNzZG4ubmV0LzIwMTUwNDE4MTYxOTA5MTQ0)
但是，当你按F9运行的时候，却没有任何反应。
这时，你需要检查一下codeblocks是否识别到了你默认的编译环境（如GCC）
点击Settings->Compiler ![这里写图片描述](https://imgconvert.csdnimg.cn/aHR0cDovL2ltZy5ibG9nLmNzZG4ubmV0LzIwMTUwNDE4MTYxOTUwMTUw)
点击Reset defaults ，然后重启codeblocks，应该就可以编译了。
当然 你喜欢用sublimetext或者VS2013或者2015，不适应codeblocks这个白底黑字的风格了怎么办？
这里有一个方法：[如何配置codeblocks-c/c++的养眼colour theme](http://jingyan.baidu.com/article/63f23628365a0c0209ab3d5c.html)
那么，就写到这里，如果您的问题还没有解决，请出门右转百度或者出门左转谷歌（需翻墙），因为博主长期不在线。。。。

## 后记
公开处刑第二篇，开始参加ACM比赛时，人家都愁怎么A题，我愁怎么装环境，所以算法拉下了，后来拼命刷leetcode什么的补裤裆，数据结构能学一辈子，加油吧自己
